/**
 *
 * Name: John Runyard
 * IT 279-002
 * Program 1
 *
 * This is the class I used to define the adt for my linked-list queue structure
 *
 */

#include "Queue.h"

/**
 * Queue constructor
 */
Queue::Queue() {
  head = NULL;
  rear = NULL;
  size = 0;
}

/**
 * Queue destructor
 */
Queue::~Queue() {
  if (head != NULL) {
    Node* temp = head;

    while (temp != NULL) {
      Node *current = temp;
      temp = temp->next;
      delete current;
    }
  }
}

/**
 * Returns value from head node
 * @return value from head node
 */
int Queue::peek() {
  if (getSize()) {
    return head->value;
  } else {
    return -1;
  }
}

/**
 * places item at rear
 * @param i integer to enqueue
 */
void Queue::enqueue(int i) {
  Node* temp = new Node(i);
  if (rear == NULL) {
    rear = temp;
    head = temp;
  } else {
    rear->next = temp;
    rear = temp;
  }
  size+=1;
}

/**
 * remove item from front of queue
 */
void Queue::dequeue() {
  if (head != NULL) {
    Node* temp = head;
    head = head->next;
    delete (temp);

    if (head == NULL) {
      rear = NULL;
    }

    size = size-1;

  }
}

/**
 * Returns true if queue is empty
 * @return bool
 */
bool Queue::isEmpty() {
  if (head==NULL) {
    return true;
  } else {
    return false;
  }
}

/**
 * Returns size of Queue
 * @return size of queue
 */
int Queue::getSize(){
  return size;
}
